# gdrive-s3-sync

Backend to Sync Google Drive Files to AWS S3 for Photography Website

Uses Google Auth Library to securily authenticate client before syncing

- Token will be stored in SSM and encrypted


### Todo / In Progress

- Conversion to Serverless
- GDrive File Pull
- File Comparison between S3, Gdrive
- S3 Upload