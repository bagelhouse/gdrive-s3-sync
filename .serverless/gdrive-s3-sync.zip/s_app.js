
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'bagelhouse',
  applicationName: 'gdrive-s3-sync',
  appUid: 'NWq0gKRwbylNMRHMrs',
  orgUid: 'df619b8a-7b85-407e-ab1b-35d6fd7f790d',
  deploymentUid: 'f766c9c2-e1ef-4693-97b6-ca9597dd6393',
  serviceName: 'gdrive-s3-sync',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.0.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'gdrive-s3-sync-dev-app', timeout: 6 };

try {
  const userHandler = require('././dist/src/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}